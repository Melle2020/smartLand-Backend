// main.ts
import { App } from './src/app';

const RPC_URL = "https://ithacanet.smartpy.io";
// const ACCOUNT_TO_CHECK = "tz1Xqa5LRU5tayDcZEFr7Sw2GjrbDBY3HtHH";
const COUNTER_CONTRACT = "KT1LmvMf9iki8J4u7rdQDEFYBkAh9onuThAX";

// new App(RPC_URL).main();
// new App(RPC_URL).addterrain({},COUNTER_CONTRACT);