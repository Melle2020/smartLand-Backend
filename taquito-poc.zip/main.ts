// main.ts
import { App } from './src/app';

const RPC_URL = "https://ithacanet.smartpy.io";
// const ACCOUNT_TO_CHECK = "tz1Xqa5LRU5tayDcZEFr7Sw2GjrbDBY3HtHH";
const COUNTER_CONTRACT = "KT1LmvMf9iki8J4u7rdQDEFYBkAh9onuThAX";
// new App(RPC_URL).main();
 const titreFoncier:any= {
    coordGeo: "12*12*88",
    dateNaissance: "12-12-2022",
    idCni: '1131313',
    idNumeroT: '11123444',
    lieuNaissance: 'Bonaberi',
    limite: '120*656',
    local: 'Douala',
    noms: 'Aziz',
    prenoms: 'Armelle'}
// new App(RPC_URL).getBalance(ACCOUNT_TO_CHECK);
// new App(RPC_URL).getContractEntrypoints(COUNTER_CONTRACT);
new App(RPC_URL).getAllTitrefoncier(COUNTER_CONTRACT);